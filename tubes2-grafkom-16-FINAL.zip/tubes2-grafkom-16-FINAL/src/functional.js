//=========Fungsi Tambahan=======//

// change degree to radian
function degToRad(degrees){
  var pi = Math.PI;
  return degrees * (pi/180);
}

// perkalian 2 buah matriks
function multiplyMatrix(a, b){
    let product = [];
    for (var i = 0; i < 4; i++) {
        for (var j = 0; j < 4; j++) {
            let sum = 0;
            for (var k = 0; k < 4; k++)
                sum = sum + a[i * 4 + k] * b[k * 4 + j];
            product[i * 4 + j] = sum;
        }
    }
    return product;
}

// penjumlahan 2 buah matriks
function sumMatrix(a, b){
    let product = [];
    for (var i = 0; i < a.length; i++) {
        product[i] = a[i] + b[i]
    }
    return product;
}

// matriks translasi
function translation(x, y, z){
    return [
        1,  0,  0,  0,
        0,  1,  0,  0,
        0,  0,  1,  0,
        x,  y,  z,  1,
    ];
}

// Get id object
function getObjectId(type) {
    for (var i = 0; i <allObjects.length; i++) {
        if (allObjects[i].type == type) {
            return i;
        }
    }
}

// Rotasi sumbu X
function xRotation(angle) {
    var cos = Math.cos(angle);
    var sin = Math.sin(angle);

    return [
        1, 0, 0, 0,
        0, cos, sin, 0,
        0, -sin, cos, 0,
        0, 0, 0, 1,
    ];
}

// Rotasi sumbu Y
function yRotation(angle) {
    var cos = Math.cos(angle);
    var sin = Math.sin(angle);

    return [
        cos, 0, sin, 0,
        0, 1, 0, 0,
        -sin, 0, cos, 0,
        0, 0, 0, 1,
    ];
}

// Rotasi sumbu Z
function zRotation(angle) {
    var cos = Math.cos(angle);
    var sin = Math.sin(angle);

    return [
        cos, sin, 0, 0,
        -sin, cos, 0, 0,
         0, 0, 1, 0,
         0, 0, 0, 1,
    ];
}

// Return center coordinate object
function getCenterOfObject(begin, end, arr) {
    var xMin = 1;
    var xMax = -1;
    var yMin = 1;
    var yMax = -1;
    
    for (var i = begin; i < end; i += 3) {
        if (xMin > arr[i]) {
            xMin = arr[i];
        }
        
        if (xMax < arr[i]) {
            xMax = arr[i];
        }

        if (yMin > arr[i+1]) {
            yMin = arr[i+1];
        }

        if (yMax < arr[i+1]) {
            yMax = arr[i+1];
        }        
    }

    var xCenter = 0.5 * (xMax + xMin);
    var yCenter = 0.5 * (yMax + yMin);
    
    return ([xCenter, yCenter]);
}

// Scaling Object
function scaleMatrix(x, y, z){
    return [
      x, 0,  0,  0,
      0, y,  0,  0,
      0, 0,  z,  0,
      0, 0,  0,  1,
    ];
}

//=========Ubah Projeksi=======//

// Update Projection Dropdown
function updateProjection(){
    var projection = document.getElementById("objectlistprojection").value;
    if(projection == 'Perspective'){
        console.log(projection)
        PerspectiveProjection()
    }

    else if(projection == 'Orthographic'){
        console.log(projection)
        OrthogonalProjection()
    }

    else if(projection == 'Oblique'){
        console.log(projection)
        ObliqueProjection()
    }
}

// Perspective Projection
function PerspectiveProjection(){

    var aspect = 1
    var near = 1
    var far = 100

    var top = Math.tan(degToRad(25)) * near;
    var right = top * aspect;
    var perspectiveMatrix = [near/right,    0    ,          0            ,          0,
                                0      , near/top,          0            ,          0,
                                0      ,    0    , -(far+near)/(far-near), (-2*far*near)/(far-near),
                                0      ,    0    ,          -1           ,          0               ];

    // Draw lagi
    for (var i = 0; i < allObjects.length; i++) {
        allObjects[i].projM = perspectiveMatrix;
        draw(allObjects[i].projM, allObjects[i].modelM, allObjects[i].offset, allObjects[i].end);  
    }
}

// Orthogonal Projection
function OrthogonalProjection(){
   var orthMatrix = [ 1,0,0,0,
                      0,1,0,0,
                      0,0,0,0, 
                      0,0,0,1 ];

    var left = -1
    var right = 1
    var bottom = -1
    var top = 1
    var near = -1
    var far = 1

   var ST = [ 2/(right - left)  ,       0          ,      0         ,-1*(left + right)/(right - left),
                    0           , 2/(top - bottom) ,      0         ,-1*(top + bottom)/(top - bottom),
                    0           ,       0          ,-2/(far - near) ,-1*(far + near )/(far - near),
                    0           ,       0          ,      0         ,         1                     ]

    console.log("st",ST)
    console.log("multiple",multiplyMatrix(orthMatrix, ST))
    // Draw lagi
    for (var i = 0; i < allObjects.length; i++) {
        allObjects[i].projM = multiplyMatrix(orthMatrix, ST);
        draw(allObjects[i].projM, allObjects[i].modelM, allObjects[i].offset, allObjects[i].end);  
    }
}

// Oblique Projection
function ObliqueProjection(){
    var orthoMatriks = [1, 0, 0 ,0,
                        0, 1, 0, 0,
                        0, 0, 0, 0,
                        0, 0, 0, 1]

    var theta = 78.0
    var phi = 75.0
    let cotheta = 1/ Math.tan((theta/180.0) * Math.PI);
    let cotphi = 1/ Math.tan((phi/180.0) * Math.PI);

    var matrixHTranspose = [1,           0,    0,0,
                            0,           1,    0,0,
                            -cotheta, -cotphi, 1,0,
                            0,           0,    0,1]

    for (var i = 0; i < allObjects.length; i++) {
    allObjects[i].projM = multiplyMatrix(matrixHTranspose, orthoMatriks);
    draw(allObjects[i].projM, allObjects[i].modelM, allObjects[i].offset, allObjects[i].end);  
    }
}



//=========Ubah Translasi=======//
function translateObject(axis, val) {
    var type = document.getElementById('select-object').value;
    var objId = getObjectId(type);

    var modelM = 0;
    if(axis == 'X') {
        modelM = translation(val, 0, 0);  
    }
    else if (axis == 'Y') {
        modelM = translation(0, val, 0);
    }
    else { // Z
        modelM = translation(0, 0, val);
    }
    
    allObjects[objId].modelM = multiplyMatrix(allObjects[objId].modelM,modelM);

    // Draw lagi
    drawToCanvas();
}

//=========Ubah Rotasi=======//
function rotateObject(axis, val) {
    var type = document.getElementById('select-object').value;
    var objId = getObjectId(type);

    var rotateVal = 0;

    var centerOfObject = getCenterOfObject(allObjects[objId].offset*12, allObjects[objId].offset*12 + allObjects[objId].length, allVertices);

    var translateM1 = translation(-centerOfObject[0], -centerOfObject[1], 0);
    var translateM2 = translation(centerOfObject[0], -0, 0);

    var model_matrix = 0;
    if (axis == 'X') {
        rotateVal = val - defaultRotX;
        model_matrix = multiplyMatrix(translateM1, multiplyMatrix(xRotation(rotateVal), translateM2));
        defaultRotX = val;
    }
    else if (axis == 'Y') {
        rotateVal = val - defaultRotY;
        model_matrix = multiplyMatrix(translateM1, multiplyMatrix(yRotation(rotateVal), translateM2));
        defaultRotY = val;
    }
    else if (axis == 'Z') {
        rotateVal = val - defaultRotZ;
        model_matrix = multiplyMatrix(translateM1, multiplyMatrix(zRotation(rotateVal), translateM2));
        defaultRotZ = val;
    }

    // allObjects[objId].modelM = modelM;
    let newModelM = allObjects[objId].modelM;
    allObjects[objId].modelM = multiplyMatrix(model_matrix, newModelM);

    // Draw
    drawToCanvas();

}

//=========Ubah Camera Angle=======//
function arcShot() {
    let val = document.getElementById('angle').value;
    val = degToRad(val);
    console.log(val);
    let move = val - defaultMove;

    viewMatrix = multiplyMatrix(yRotation(move), viewMatrix);
    drawToCanvas();

    defaultMove = val;
}

function zoomShot(val) {
    viewMatrix = multiplyMatrix(scaleMatrix(val, val, val), viewMatrix);
    drawToCanvas();
}


//=========Save dan Load=======//

// Save
const saveData = () => {
    const data = [...allObjects];

    console.log(data);

    const a = document.createElement("a");
    const file = new Blob([JSON.stringify(data)], { type: "json" });
    a.href = URL.createObjectURL(file);
    a.download = "allobjects.json";
    a.click();
    URL.revokeObjectURL(a.href);
};
var saveButton = document.getElementById("save");
saveButton.addEventListener("click", saveData);


// Load
const loadData = (e) => {
    const file = e.target.files[0];
    var reader = new FileReader();

    reader.addEventListener("load", function (e) {
        let data = e.target.result;
        data = JSON.parse(data);
        allObjects = [...data];
        drawToCanvas();
    });
    reader.readAsBinaryString(file);
};

var loadButton = document.getElementById("load");
loadButton.addEventListener("change", loadData);



//=========Reset All Value=======//
function defaultValue() {
    document.getElementById('rotateX').value = 0;
    document.getElementById('rotateY').value = 0;
    document.getElementById('rotateZ').value = 0;

    defaultRotX = 0;
    defaultRotY = 0;
    defaultRotZ = 0;
}

//=========Ubah Ukuran Object=======//
function ScalingObject(valueData){
    var type = document.getElementById('select-object').value;
    var objId = getObjectId(type);
    
    let centerPoint = getCenterOfObject(allObjects[objId].offset*12, allObjects[objId].offset*12 + allObjects[objId].length,allVertices);
    var scale_matrix = scaleMatrix(valueData, valueData, valueData);
    var matriksA = translation(centerPoint[0], centerPoint[1], 0);
    var matriksB = translation(-centerPoint[0], -centerPoint[1], 0);

    let currentModelMatrix = allObjects[objId].modelM;
    allObjects[objId].modelM = multiplyMatrix(multiplyMatrix(matriksB, multiplyMatrix(scale_matrix, matriksA)), currentModelMatrix);

    // Draw
    for (var i = 0; i < allObjects.length; i++) {
        draw(allObjects[i].projM, allObjects[i].modelM, allObjects[i].offset, allObjects[i].end);  
    }
}