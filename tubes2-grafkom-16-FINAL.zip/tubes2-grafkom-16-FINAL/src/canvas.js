function createAllBuffer(){
    // Bikin buffer vertex, color, normal
    var vertexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(allVertices), gl.STATIC_DRAW);

    var colorBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(allColors), gl.STATIC_DRAW);

    var normalBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, normalBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(allNormals),gl.STATIC_DRAW);

    // Setting vertex shader
    pMatrix = gl.getUniformLocation(shaderProgram, "P");
    vMatrix = gl.getUniformLocation(shaderProgram, "V");
    mMatrix = gl.getUniformLocation(shaderProgram, "M");
    nMatrix = gl.getUniformLocation(shaderProgram, "N");

    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    var pos = gl.getAttribLocation(shaderProgram, "position");
    gl.vertexAttribPointer(pos, 3, gl.FLOAT, false, 0,0);
    gl.enableVertexAttribArray(pos);

    gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer);
    var col = gl.getAttribLocation(shaderProgram, "color");
    gl.vertexAttribPointer(col, 3, gl.FLOAT, false,0,0) ;
    gl.enableVertexAttribArray(col);

    gl.bindBuffer(gl.ARRAY_BUFFER, normalBuffer);
    var norm = gl.getAttribLocation(shaderProgram, "normal");
    gl.vertexAttribPointer(norm, 3, gl.FLOAT, false,0,0);
    gl.enableVertexAttribArray(norm);
    gl.useProgram(shaderProgram);

    gl.enable(gl.DEPTH_TEST);

    gl.depthFunc(gl.LEQUAL);

    gl.clearColor(0, 0, 0, 0);
    gl.clearDepth(1.0);
    gl.viewport(0.0, 0.0, canvas.width, canvas.height);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
}

//=========Draw Object=======//
function draw(projectionMatrix, modelMatrix, start, end){ 
   gl.uniformMatrix4fv(pMatrix, false, projectionMatrix);
   gl.uniformMatrix4fv(mMatrix, false, modelMatrix);
   gl.uniformMatrix4fv(vMatrix, false, viewMatrix);
   
   if (shadingOn) {
      shading(modelMatrix, viewMatrix);
   }
   else{
      let normalMatrix = [0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0];
      gl.uniformMatrix4fv(nMatrix, false, normalMatrix);
   }

   // drawing function
   for (var i = start; i < end; i++){
      gl.drawArrays(gl.TRIANGLE_FAN, i*4, 4);
   }
}

function drawToCanvas() {
   for (var i = 0; i < allObjects.length; i++) {
      draw(allObjects[i].projM, allObjects[i].modelM, allObjects[i].offset, allObjects[i].end);  
   }
}

createAllBuffer();
updateProjection();
