const canvas = document.querySelector('#glcanvas');
canvas.width = 600;
canvas.height = 600;

// Initialize the GL context
const gl = canvas.getContext('webgl');

if (!gl) {
    alert('Unable to initialize WebGL.');
}

// Vertex shader source code
var vertCode = `
    attribute vec3 position;
    attribute vec3 normal;

    uniform mat4 P;
    uniform mat4 V;
    uniform mat4 M;
    uniform mat4 N;

    attribute vec3 color;
    varying vec3 vLighting;
    varying vec3 vColor;

    void main() {
        gl_Position = P*V*M*vec4(position, 1.0);
        highp vec3 ambientLight = vec3(0.3, 0.3, 0.3);
        highp vec3 directionalLightColor = vec3(1, 1, 1);
        highp vec3 directionalVector = normalize(vec3(0.85, 0.8, 0.75));
        highp vec4 transformedNormal = N*vec4(normal, 1.0);
        
        float directional = max(dot(transformedNormal.xyz, directionalVector), 0.0);
        vLighting = ambientLight + (directionalLightColor * directional);
        vColor = color;
    }
    `;

// Create a vertex shader object
var vertShader = gl.createShader(gl.VERTEX_SHADER);

// Fragment shader source code
var fragCode = 'precision mediump float;'+
    'varying vec3 vColor;'+
    'varying vec3 vLighting;'+
    
    'void main() {'+
        'gl_FragColor = vec4(vColor, 1.0);'+
        'gl_FragColor.rgb *= vLighting;'+
    '}';

// Create fragment shader object
var fragShader = gl.createShader(gl.FRAGMENT_SHADER);

// Create a shader program object to store
var shaderProgram = gl.createProgram();

function setupShader(){
    // Attach vertex shader source code
    gl.shaderSource(vertShader, vertCode);
    // Compile the vertex shader
    gl.compileShader(vertShader);
    // Attach fragment shader source code
    gl.shaderSource(fragShader, fragCode);
    // Compile the fragment shader
    gl.compileShader(fragShader);
}

function setupProgram(){
    // Attach a vertex shader
    gl.attachShader(shaderProgram, vertShader);
    // Attach a fragment shader
    gl.attachShader(shaderProgram, fragShader);
    // Link both the programs
    gl.linkProgram(shaderProgram);
}

setupShader();
setupProgram();