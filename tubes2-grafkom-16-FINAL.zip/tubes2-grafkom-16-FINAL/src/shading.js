function inverseMatrix(matrix) {
    var E = [];
    var temp;
   
    for (var i = 0; i < matrix.length; i++) {
      E[i] = [];
    }
   
    for (i = 0; i < matrix.length; i++) {
      for (var j = 0; j < matrix.length; j++) {
        E[i][j] = 0;
        if (i == j)
          E[i][j] = 1;
      }
    }
   
    for (var k = 0; k < matrix.length; k++) {
      temp = matrix[k][k];
      for (var j = 0; j < matrix.length; j++) {
        matrix[k][j] /= temp;
        matrix[k][j] /= temp;
      }
   
      for (var i = k + 1; i < matrix.length; i++) {
        temp = matrix[i][k];
        for (var j = 0; j < matrix.length; j++) {
          matrix[i][j] -= matrix[k][j] * temp;
          E[i][j] -= E[k][j] * temp;
        }
      }
    }
   
    for (var k = matrix.length - 1; k > 0; k--) {
      for (var i = k - 1; i >= 0; i--) {
        temp = matrix[i][k];
        for (var j = 0; j < matrix.length; j++) {
          matrix[i][j] -= matrix[k][j] * temp;
          E[i][j] -= E[k][j] * temp;
        }
      }
    }
   
    for (var i = 0; i < matrix.length; i++) {
      for (var j = 0; j < matrix.length; j++) {
        matrix[i][j] = E[i][j];
      }
    }
    return matrix;
  }

  function transposeMatrix(matrix) {
    return matrix[0].map((i) => matrix.map(row => row[i]));
  }

function doShading() {
    var val = document.getElementById('shading-select').value;
    if (val == "on") {
      shadingOn = true;
    } else {
      shadingOn = false;
    }
    drawToCanvas();
}

function shading(modelMat, viewMat) {
    var mmat = multiplyMatrix(modelMat, viewMat);
    var MvMat = [];

    for (var i = 0; i<16; i += 4){
        MvMat.push([mmat[i], mmat[i+1], mmat[i+2], mmat[i+3]]);
    }

    normalMat = transposeMatrix(inverseMatrix(MvMat));
    var normalVector = [];
    for (var i = 0; i<4; i++) {
        for (var j = 0; j<4; j++) {
            normalVector.push(normalMat[i][j]);
        }
    }
    gl.uniformMatrix4fv(nMatrix, false, normalVector);
}